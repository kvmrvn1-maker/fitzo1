import { useState, useCallback } from 'react';

export type BodyType = 'ectomorph' | 'mesomorph' | 'endomorph';
export type Goal = 'loseWeight' | 'gainWeight' | 'maintain' | 'buildMuscle';

export interface AnalysisResult {
  bodyType: BodyType;
  goal: Goal;
  confidence: number;
  estimatedBMI: number;
  description: string;
}

export function useImageAnalysis() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const analyzeImage = useCallback(async (imageFile: File): Promise<void> => {
    setIsAnalyzing(true);
    setError(null);

    try {
      // Simulate AI analysis with a delay
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Mock analysis based on file properties
      const fileSize = imageFile.size;
      const randomSeed = fileSize % 100;

      let bodyType: BodyType;
      let goal: Goal;
      let estimatedBMI: number;

      if (randomSeed < 25) {
        bodyType = 'ectomorph';
        goal = 'gainWeight';
        estimatedBMI = 18.5 + Math.random() * 3;
      } else if (randomSeed < 50) {
        bodyType = 'ectomorph';
        goal = 'buildMuscle';
        estimatedBMI = 19 + Math.random() * 2;
      } else if (randomSeed < 70) {
        bodyType = 'mesomorph';
        goal = 'maintain';
        estimatedBMI = 22 + Math.random() * 3;
      } else if (randomSeed < 85) {
        bodyType = 'mesomorph';
        goal = 'buildMuscle';
        estimatedBMI = 23 + Math.random() * 2;
      } else {
        bodyType = 'endomorph';
        goal = 'loseWeight';
        estimatedBMI = 27 + Math.random() * 5;
      }

      const descriptions: Record<BodyType, string> = {
        ectomorph: 'İncə bədən quruluşu, sürətli metabolizm',
        mesomorph: 'Atletik bədən quruluşu, balanced metabolizm',
        endomorph: 'Geniş bədən quruluşu, yavaş metabolizm',
      };

      setResult({
        bodyType,
        goal,
        confidence: 85 + Math.random() * 10,
        estimatedBMI: Math.round(estimatedBMI * 10) / 10,
        description: descriptions[bodyType],
      });
    } catch (err) {
      setError('analysisFailed');
    } finally {
      setIsAnalyzing(false);
    }
  }, []);

  const reset = useCallback(() => {
    setResult(null);
    setError(null);
    setIsAnalyzing(false);
  }, []);

  return {
    isAnalyzing,
    result,
    error,
    analyzeImage,
    reset,
  };
}
