import { useCallback } from 'react';
import type { BodyType, Goal } from './useImageAnalysis';

export interface Exercise {
  name: string;
  nameRu: string;
  nameEn: string;
  sets: number;
  reps: string;
  rest: string;
  equipment: string;
  equipmentRu: string;
  equipmentEn: string;
}

export interface WorkoutDay {
  day: string;
  dayRu: string;
  dayEn: string;
  focus: string;
  focusRu: string;
  focusEn: string;
  exercises: Exercise[];
}

export interface WorkoutProgram {
  level: 'beginner' | 'intermediate' | 'advanced';
  duration: string;
  daysPerWeek: number;
  workouts: WorkoutDay[];
}

const workoutPrograms: Record<BodyType, Record<Goal, WorkoutProgram>> = {
  ectomorph: {
    gainWeight: {
      level: 'intermediate',
      duration: '45-60 dəqiqə',
      daysPerWeek: 4,
      workouts: [
        {
          day: 'Bazar ertəsi - Göğüs & Triceps',
          dayRu: 'Понедельник - Грудь & Трицепс',
          dayEn: 'Monday - Chest & Triceps',
          focus: 'Kütlə qazanma',
          focusRu: 'Набор массы',
          focusEn: 'Mass gain',
          exercises: [
            { name: 'Bench Press', nameRu: 'Жим лёжа', nameEn: 'Bench Press', sets: 4, reps: '8-10', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Incline Dumbbell Press', nameRu: 'Жим гантелей на наклонной', nameEn: 'Incline Dumbbell Press', sets: 3, reps: '10-12', rest: '90 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Dips', nameRu: 'Отжимания на брусьях', nameEn: 'Dips', sets: 3, reps: '8-12', rest: '90 san', equipment: 'Dip Bars', equipmentRu: 'Брусья', equipmentEn: 'Dip Bars' },
            { name: 'Tricep Pushdowns', nameRu: 'Разгибания трицепса', nameEn: 'Tricep Pushdowns', sets: 3, reps: '12-15', rest: '60 san', equipment: 'Cable', equipmentRu: 'Трос', equipmentEn: 'Cable' },
          ],
        },
        {
          day: 'Çərşənbə axşamı - Arxa & Biceps',
          dayRu: 'Вторник - Спина & Бицепс',
          dayEn: 'Tuesday - Back & Biceps',
          focus: 'Kütlə qazanma',
          focusRu: 'Набор массы',
          focusEn: 'Mass gain',
          exercises: [
            { name: 'Deadlift', nameRu: 'Становая тяга', nameEn: 'Deadlift', sets: 4, reps: '6-8', rest: '3 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Pull-ups', nameRu: 'Подтягивания', nameEn: 'Pull-ups', sets: 3, reps: '8-12', rest: '2 dəq', equipment: 'Pull-up Bar', equipmentRu: 'Турник', equipmentEn: 'Pull-up Bar' },
            { name: 'Barbell Rows', nameRu: 'Тяга штанги в наклоне', nameEn: 'Barbell Rows', sets: 3, reps: '10-12', rest: '90 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Barbell Curls', nameRu: 'Сгибания со штангой', nameEn: 'Barbell Curls', sets: 3, reps: '10-12', rest: '60 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
          ],
        },
        {
          day: 'Cümə - Ayaq & Çiyin',
          dayRu: 'Пятница - Ноги & Плечи',
          dayEn: 'Friday - Legs & Shoulders',
          focus: 'Kütlə qazanma',
          focusRu: 'Набор массы',
          focusEn: 'Mass gain',
          exercises: [
            { name: 'Squats', nameRu: 'Приседания', nameEn: 'Squats', sets: 4, reps: '8-10', rest: '3 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Leg Press', nameRu: 'Жим ногами', nameEn: 'Leg Press', sets: 3, reps: '12-15', rest: '2 dəq', equipment: 'Machine', equipmentRu: 'Тренажёр', equipmentEn: 'Machine' },
            { name: 'Military Press', nameRu: 'Армейский жим', nameEn: 'Military Press', sets: 3, reps: '8-10', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Lateral Raises', nameRu: 'Разведения в стороны', nameEn: 'Lateral Raises', sets: 3, reps: '12-15', rest: '60 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
          ],
        },
        {
          day: 'Şənbə - Tam Bədən',
          dayRu: 'Суббота - Все тело',
          dayEn: 'Saturday - Full Body',
          focus: 'Kütlə qazanma',
          focusRu: 'Набор массы',
          focusEn: 'Mass gain',
          exercises: [
            { name: 'Clean and Press', nameRu: 'Рывок и жим', nameEn: 'Clean and Press', sets: 3, reps: '6-8', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Lunges', nameRu: 'Выпады', nameEn: 'Lunges', sets: 3, reps: '10 hər tərəf', rest: '90 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Face Pulls', nameRu: 'Тяга к лицу', nameEn: 'Face Pulls', sets: 3, reps: '15-20', rest: '60 san', equipment: 'Cable', equipmentRu: 'Трос', equipmentEn: 'Cable' },
            { name: 'Farmer Walks', nameRu: 'Ходьба фермера', nameEn: 'Farmer Walks', sets: 3, reps: '30 metr', rest: '90 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
          ],
        },
      ],
    },
    buildMuscle: {
      level: 'intermediate',
      duration: '50-65 dəqiqə',
      daysPerWeek: 5,
      workouts: [
        {
          day: 'Bazar ertəsi - Göğüs',
          dayRu: 'Понедельник - Грудь',
          dayEn: 'Monday - Chest',
          focus: 'Əzələ yığmaq',
          focusRu: 'Набор мышц',
          focusEn: 'Muscle building',
          exercises: [
            { name: 'Bench Press', nameRu: 'Жим лёжа', nameEn: 'Bench Press', sets: 4, reps: '6-8', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Incline Bench', nameRu: 'Жим на наклонной', nameEn: 'Incline Bench', sets: 4, reps: '8-10', rest: '90 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Dumbbell Flyes', nameRu: 'Разведения гантелей', nameEn: 'Dumbbell Flyes', sets: 3, reps: '12-15', rest: '60 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Cable Crossovers', nameRu: 'Сведения в кроссовере', nameEn: 'Cable Crossovers', sets: 3, reps: '15-20', rest: '60 san', equipment: 'Cable', equipmentRu: 'Трос', equipmentEn: 'Cable' },
          ],
        },
        {
          day: 'Çərşənbə axşamı - Arxa',
          dayRu: 'Вторник - Спина',
          dayEn: 'Tuesday - Back',
          focus: 'Əzələ yığmaq',
          focusRu: 'Набор мышц',
          focusEn: 'Muscle building',
          exercises: [
            { name: 'Deadlift', nameRu: 'Становая тяга', nameEn: 'Deadlift', sets: 4, reps: '5-6', rest: '3 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Weighted Pull-ups', nameRu: 'Подтягивания с весом', nameEn: 'Weighted Pull-ups', sets: 4, reps: '6-8', rest: '2 dəq', equipment: 'Pull-up Bar + Weight', equipmentRu: 'Турник + вес', equipmentEn: 'Pull-up Bar + Weight' },
            { name: 'T-Bar Rows', nameRu: 'Тяга Т-грифа', nameEn: 'T-Bar Rows', sets: 3, reps: '10-12', rest: '90 san', equipment: 'T-Bar', equipmentRu: 'Т-гриф', equipmentEn: 'T-Bar' },
            { name: 'Straight Arm Pulldowns', nameRu: 'Пулдауны с прямыми руками', nameEn: 'Straight Arm Pulldowns', sets: 3, reps: '15-20', rest: '60 san', equipment: 'Cable', equipmentRu: 'Трос', equipmentEn: 'Cable' },
          ],
        },
        {
          day: 'Çərşənbə - Çiyin & Trap',
          dayRu: 'Среда - Плечи & Трапеции',
          dayEn: 'Wednesday - Shoulders & Traps',
          focus: 'Əzələ yığmaq',
          focusRu: 'Набор мышц',
          focusEn: 'Muscle building',
          exercises: [
            { name: 'Overhead Press', nameRu: 'Жим над головой', nameEn: 'Overhead Press', sets: 4, reps: '6-8', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Arnold Press', nameRu: 'Жим Арнольда', nameEn: 'Arnold Press', sets: 3, reps: '10-12', rest: '90 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Upright Rows', nameRu: 'Тяга к подбородку', nameEn: 'Upright Rows', sets: 3, reps: '12-15', rest: '60 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Shrugs', nameRu: 'Шраги', nameEn: 'Shrugs', sets: 4, reps: '12-15', rest: '60 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
          ],
        },
        {
          day: 'Cümə - Ayaq',
          dayRu: 'Пятница - Ноги',
          dayEn: 'Friday - Legs',
          focus: 'Əzələ yığmaq',
          focusRu: 'Набор мышц',
          focusEn: 'Muscle building',
          exercises: [
            { name: 'Squats', nameRu: 'Приседания', nameEn: 'Squats', sets: 5, reps: '6-8', rest: '3 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Romanian Deadlift', nameRu: 'Румынская тяга', nameEn: 'Romanian Deadlift', sets: 4, reps: '8-10', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Leg Extensions', nameRu: 'Разгибания ног', nameEn: 'Leg Extensions', sets: 3, reps: '15-20', rest: '60 san', equipment: 'Machine', equipmentRu: 'Тренажёр', equipmentEn: 'Machine' },
            { name: 'Hamstring Curls', nameRu: 'Сгибания ног', nameEn: 'Hamstring Curls', sets: 3, reps: '12-15', rest: '60 san', equipment: 'Machine', equipmentRu: 'Тренажёр', equipmentEn: 'Machine' },
          ],
        },
        {
          day: 'Şənbə - Qollar',
          dayRu: 'Суббота - Руки',
          dayEn: 'Saturday - Arms',
          focus: 'Əzələ yığmaq',
          focusRu: 'Набор мышц',
          focusEn: 'Muscle building',
          exercises: [
            { name: 'Close Grip Bench', nameRu: 'Жим узким хватом', nameEn: 'Close Grip Bench', sets: 4, reps: '8-10', rest: '90 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Skullcrushers', nameRu: 'Французский жим', nameEn: 'Skullcrushers', sets: 3, reps: '10-12', rest: '90 san', equipment: 'EZ Bar', equipmentRu: 'EZ-гриф', equipmentEn: 'EZ Bar' },
            { name: 'Barbell Curls', nameRu: 'Сгибания со штангой', nameEn: 'Barbell Curls', sets: 4, reps: '8-10', rest: '90 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Hammer Curls', nameRu: 'Молотковые сгибания', nameEn: 'Hammer Curls', sets: 3, reps: '12-15', rest: '60 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
          ],
        },
      ],
    },
    loseWeight: {
      level: 'beginner',
      duration: '30-40 dəqiqə',
      daysPerWeek: 3,
      workouts: [
        {
          day: 'Bazar ertəsi - Tam Bədən',
          dayRu: 'Понедельник - Все тело',
          dayEn: 'Monday - Full Body',
          focus: 'Yağ yandırmaq',
          focusRu: 'Сжигание жира',
          focusEn: 'Fat burning',
          exercises: [
            { name: 'Jumping Jacks', nameRu: 'Прыжки с разведением', nameEn: 'Jumping Jacks', sets: 3, reps: '30 san', rest: '30 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Bodyweight Squats', nameRu: 'Приседания с весом тела', nameEn: 'Bodyweight Squats', sets: 3, reps: '15-20', rest: '45 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Push-ups', nameRu: 'Отжимания', nameEn: 'Push-ups', sets: 3, reps: '10-15', rest: '45 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Mountain Climbers', nameRu: 'Горные альпинисты', nameEn: 'Mountain Climbers', sets: 3, reps: '20 san', rest: '30 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
          ],
        },
        {
          day: 'Çərşənbə - Kardio',
          dayRu: 'Среда - Кардио',
          dayEn: 'Wednesday - Cardio',
          focus: 'Yağ yandırmaq',
          focusRu: 'Сжигание жира',
          focusEn: 'Fat burning',
          exercises: [
            { name: 'High Knees', nameRu: 'Бег с высокими коленями', nameEn: 'High Knees', sets: 4, reps: '30 san', rest: '30 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Burpees', nameRu: 'Бёрпи', nameEn: 'Burpees', sets: 3, reps: '8-12', rest: '60 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Jump Rope', nameRu: 'Прыжки со скакалкой', nameEn: 'Jump Rope', sets: 3, reps: '1 dəq', rest: '30 san', equipment: 'Jump Rope', equipmentRu: 'Скакалка', equipmentEn: 'Jump Rope' },
            { name: 'Plank', nameRu: 'Планка', nameEn: 'Plank', sets: 3, reps: '30-45 san', rest: '30 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
          ],
        },
        {
          day: 'Cümə - Güc & Kardio',
          dayRu: 'Пятница - Сила & Кардио',
          dayEn: 'Friday - Strength & Cardio',
          focus: 'Yağ yandırmaq',
          focusRu: 'Сжигание жира',
          focusEn: 'Fat burning',
          exercises: [
            { name: 'Kettlebell Swings', nameRu: 'Махи гирей', nameEn: 'Kettlebell Swings', sets: 4, reps: '15-20', rest: '45 san', equipment: 'Kettlebell', equipmentRu: 'Гиря', equipmentEn: 'Kettlebell' },
            { name: 'Box Jumps', nameRu: 'Прыжки на ящик', nameEn: 'Box Jumps', sets: 3, reps: '10-12', rest: '60 san', equipment: 'Plyo Box', equipmentRu: 'Плио бокс', equipmentEn: 'Plyo Box' },
            { name: 'Battle Ropes', nameRu: 'Боевые канаты', nameEn: 'Battle Ropes', sets: 3, reps: '30 san', rest: '30 san', equipment: 'Battle Ropes', equipmentRu: 'Боевые канаты', equipmentEn: 'Battle Ropes' },
            { name: 'Russian Twists', nameRu: 'Русские скручивания', nameEn: 'Russian Twists', sets: 3, reps: '20 hər tərəf', rest: '30 san', equipment: 'Medicine Ball', equipmentRu: 'Медбол', equipmentEn: 'Medicine Ball' },
          ],
        },
      ],
    },
    maintain: {
      level: 'beginner',
      duration: '35-45 dəqiqə',
      daysPerWeek: 3,
      workouts: [
        {
          day: 'Bazar ertəsi - Üst Bədən',
          dayRu: 'Понедельник - Верх тела',
          dayEn: 'Monday - Upper Body',
          focus: 'Formada qalmaq',
          focusRu: 'Поддержание формы',
          focusEn: 'Maintenance',
          exercises: [
            { name: 'Push-ups', nameRu: 'Отжимания', nameEn: 'Push-ups', sets: 3, reps: '12-15', rest: '60 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Dumbbell Rows', nameRu: 'Тяга гантелей', nameEn: 'Dumbbell Rows', sets: 3, reps: '12 hər tərəf', rest: '60 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Shoulder Press', nameRu: 'Жим плечами', nameEn: 'Shoulder Press', sets: 3, reps: '10-12', rest: '60 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Plank', nameRu: 'Планка', nameEn: 'Plank', sets: 3, reps: '45 san', rest: '45 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
          ],
        },
        {
          day: 'Çərşənbə - Aşağı Bədən',
          dayRu: 'Среда - Низ тела',
          dayEn: 'Wednesday - Lower Body',
          focus: 'Formada qalmaq',
          focusRu: 'Поддержание формы',
          focusEn: 'Maintenance',
          exercises: [
            { name: 'Goblet Squats', nameRu: 'Приседания с гирей', nameEn: 'Goblet Squats', sets: 3, reps: '12-15', rest: '60 san', equipment: 'Kettlebell', equipmentRu: 'Гиря', equipmentEn: 'Kettlebell' },
            { name: 'Lunges', nameRu: 'Выпады', nameEn: 'Lunges', sets: 3, reps: '10 hər tərəf', rest: '60 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Glute Bridges', nameRu: 'Мосты для ягодиц', nameEn: 'Glute Bridges', sets: 3, reps: '15-20', rest: '45 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Calf Raises', nameRu: 'Подъёмы на носки', nameEn: 'Calf Raises', sets: 3, reps: '15-20', rest: '45 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
          ],
        },
        {
          day: 'Cümə - Tam Bədən',
          dayRu: 'Пятница - Все тело',
          dayEn: 'Friday - Full Body',
          focus: 'Formada qalmaq',
          focusRu: 'Поддержание формы',
          focusEn: 'Maintenance',
          exercises: [
            { name: 'Dumbbell Thrusters', nameRu: 'Трастеры с гантелями', nameEn: 'Dumbbell Thrusters', sets: 3, reps: '10-12', rest: '90 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Renegade Rows', nameRu: 'Ренегад ряды', nameEn: 'Renegade Rows', sets: 3, reps: '8 hər tərəf', rest: '60 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Kettlebell Swings', nameRu: 'Махи гирей', nameEn: 'Kettlebell Swings', sets: 3, reps: '15', rest: '60 san', equipment: 'Kettlebell', equipmentRu: 'Гиря', equipmentEn: 'Kettlebell' },
            { name: 'Dead Bug', nameRu: 'Мёртвый жук', nameEn: 'Dead Bug', sets: 3, reps: '10 hər tərəf', rest: '45 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
          ],
        },
      ],
    },
  },
  mesomorph: {
    gainWeight: {
      level: 'intermediate',
      duration: '50-60 dəqiqə',
      daysPerWeek: 4,
      workouts: [
        {
          day: 'Bazar ertəsi - Göğüs & Triceps',
          dayRu: 'Понедельник - Грудь & Трицепс',
          dayEn: 'Monday - Chest & Triceps',
          focus: 'Kütlə qazanma',
          focusRu: 'Набор массы',
          focusEn: 'Mass gain',
          exercises: [
            { name: 'Bench Press', nameRu: 'Жим лёжа', nameEn: 'Bench Press', sets: 4, reps: '8-10', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Incline Dumbbell Press', nameRu: 'Жим гантелей на наклонной', nameEn: 'Incline Dumbbell Press', sets: 3, reps: '10-12', rest: '90 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Dips', nameRu: 'Отжимания на брусьях', nameEn: 'Dips', sets: 3, reps: '8-12', rest: '90 san', equipment: 'Dip Bars', equipmentRu: 'Брусья', equipmentEn: 'Dip Bars' },
            { name: 'Tricep Pushdowns', nameRu: 'Разгибания трицепса', nameEn: 'Tricep Pushdowns', sets: 3, reps: '12-15', rest: '60 san', equipment: 'Cable', equipmentRu: 'Трос', equipmentEn: 'Cable' },
          ],
        },
        {
          day: 'Çərşənbə axşamı - Arxa & Biceps',
          dayRu: 'Вторник - Спина & Бицепс',
          dayEn: 'Tuesday - Back & Biceps',
          focus: 'Kütlə qazanma',
          focusRu: 'Набор массы',
          focusEn: 'Mass gain',
          exercises: [
            { name: 'Deadlift', nameRu: 'Становая тяга', nameEn: 'Deadlift', sets: 4, reps: '6-8', rest: '3 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Pull-ups', nameRu: 'Подтягивания', nameEn: 'Pull-ups', sets: 3, reps: '8-12', rest: '2 dəq', equipment: 'Pull-up Bar', equipmentRu: 'Турник', equipmentEn: 'Pull-up Bar' },
            { name: 'Barbell Rows', nameRu: 'Тяга штанги в наклоне', nameEn: 'Barbell Rows', sets: 3, reps: '10-12', rest: '90 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Barbell Curls', nameRu: 'Сгибания со штангой', nameEn: 'Barbell Curls', sets: 3, reps: '10-12', rest: '60 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
          ],
        },
        {
          day: 'Cümə - Ayaq & Çiyin',
          dayRu: 'Пятница - Ноги & Плечи',
          dayEn: 'Friday - Legs & Shoulders',
          focus: 'Kütlə qazanma',
          focusRu: 'Набор массы',
          focusEn: 'Mass gain',
          exercises: [
            { name: 'Squats', nameRu: 'Приседания', nameEn: 'Squats', sets: 4, reps: '8-10', rest: '3 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Leg Press', nameRu: 'Жим ногами', nameEn: 'Leg Press', sets: 3, reps: '12-15', rest: '2 dəq', equipment: 'Machine', equipmentRu: 'Тренажёр', equipmentEn: 'Machine' },
            { name: 'Military Press', nameRu: 'Армейский жим', nameEn: 'Military Press', sets: 3, reps: '8-10', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Lateral Raises', nameRu: 'Разведения в стороны', nameEn: 'Lateral Raises', sets: 3, reps: '12-15', rest: '60 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
          ],
        },
        {
          day: 'Şənbə - Tam Bədən',
          dayRu: 'Суббота - Все тело',
          dayEn: 'Saturday - Full Body',
          focus: 'Kütlə qazanma',
          focusRu: 'Набор массы',
          focusEn: 'Mass gain',
          exercises: [
            { name: 'Clean and Press', nameRu: 'Рывок и жим', nameEn: 'Clean and Press', sets: 3, reps: '6-8', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Lunges', nameRu: 'Выпады', nameEn: 'Lunges', sets: 3, reps: '10 hər tərəf', rest: '90 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Face Pulls', nameRu: 'Тяга к лицу', nameEn: 'Face Pulls', sets: 3, reps: '15-20', rest: '60 san', equipment: 'Cable', equipmentRu: 'Трос', equipmentEn: 'Cable' },
            { name: 'Farmer Walks', nameRu: 'Ходьба фермера', nameEn: 'Farmer Walks', sets: 3, reps: '30 metr', rest: '90 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
          ],
        },
      ],
    },
    buildMuscle: {
      level: 'advanced',
      duration: '60-75 dəqiqə',
      daysPerWeek: 5,
      workouts: [
        {
          day: 'Bazar ertəsi - Göğüs',
          dayRu: 'Понедельник - Грудь',
          dayEn: 'Monday - Chest',
          focus: 'Əzələ yığmaq',
          focusRu: 'Набор мышц',
          focusEn: 'Muscle building',
          exercises: [
            { name: 'Bench Press', nameRu: 'Жим лёжа', nameEn: 'Bench Press', sets: 5, reps: '5-6', rest: '2-3 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Incline Dumbbell Press', nameRu: 'Жим гантелей на наклонной', nameEn: 'Incline Dumbbell Press', sets: 4, reps: '8-10', rest: '90 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Weighted Dips', nameRu: 'Отжимания на брусьях с весом', nameEn: 'Weighted Dips', sets: 4, reps: '8-10', rest: '2 dəq', equipment: 'Dip Belt', equipmentRu: 'Пояс для отягощения', equipmentEn: 'Dip Belt' },
            { name: 'Cable Flyes', nameRu: 'Разведения в кроссовере', nameEn: 'Cable Flyes', sets: 3, reps: '15-20', rest: '60 san', equipment: 'Cable', equipmentRu: 'Трос', equipmentEn: 'Cable' },
          ],
        },
        {
          day: 'Çərşənbə axşamı - Arxa',
          dayRu: 'Вторник - Спина',
          dayEn: 'Tuesday - Back',
          focus: 'Əzələ yığmaq',
          focusRu: 'Набор мышц',
          focusEn: 'Muscle building',
          exercises: [
            { name: 'Deadlift', nameRu: 'Становая тяга', nameEn: 'Deadlift', sets: 5, reps: '3-5', rest: '3-4 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Weighted Pull-ups', nameRu: 'Подтягивания с весом', nameEn: 'Weighted Pull-ups', sets: 4, reps: '6-8', rest: '2 dəq', equipment: 'Dip Belt', equipmentRu: 'Пояс для отягощения', equipmentEn: 'Dip Belt' },
            { name: 'Chest-Supported Rows', nameRu: 'Тяга с опорой на грудь', nameEn: 'Chest-Supported Rows', sets: 4, reps: '10-12', rest: '90 san', equipment: 'Machine', equipmentRu: 'Тренажёр', equipmentEn: 'Machine' },
            { name: 'Lat Pulldowns', nameRu: 'Тяга верхнего блока', nameEn: 'Lat Pulldowns', sets: 3, reps: '12-15', rest: '60 san', equipment: 'Cable', equipmentRu: 'Трос', equipmentEn: 'Cable' },
          ],
        },
        {
          day: 'Çərşənbə - Çiyin & Trap',
          dayRu: 'Среда - Плечи & Трапеции',
          dayEn: 'Wednesday - Shoulders & Traps',
          focus: 'Əzələ yığmaq',
          focusRu: 'Набор мышц',
          focusEn: 'Muscle building',
          exercises: [
            { name: 'Overhead Press', nameRu: 'Жим над головой', nameEn: 'Overhead Press', sets: 5, reps: '5-6', rest: '2-3 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Seated Dumbbell Press', nameRu: 'Жим гантелей сидя', nameEn: 'Seated Dumbbell Press', sets: 4, reps: '8-10', rest: '90 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Cable Lateral Raises', nameRu: 'Разведения в стороны на тросе', nameEn: 'Cable Lateral Raises', sets: 4, reps: '15-20', rest: '60 san', equipment: 'Cable', equipmentRu: 'Трос', equipmentEn: 'Cable' },
            { name: 'Barbell Shrugs', nameRu: 'Шраги со штангой', nameEn: 'Barbell Shrugs', sets: 4, reps: '12-15', rest: '60 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
          ],
        },
        {
          day: 'Cümə - Ayaq',
          dayRu: 'Пятница - Ноги',
          dayEn: 'Friday - Legs',
          focus: 'Əzələ yığmaq',
          focusRu: 'Набор мышц',
          focusEn: 'Muscle building',
          exercises: [
            { name: 'Squats', nameRu: 'Приседания', nameEn: 'Squats', sets: 5, reps: '5-6', rest: '3-4 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Romanian Deadlift', nameRu: 'Румынская тяга', nameEn: 'Romanian Deadlift', sets: 4, reps: '8-10', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Bulgarian Split Squats', nameRu: 'Болгарские сплит-приседания', nameEn: 'Bulgarian Split Squats', sets: 3, reps: '10 hər tərəf', rest: '90 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Leg Curls', nameRu: 'Сгибания ног', nameEn: 'Leg Curls', sets: 3, reps: '12-15', rest: '60 san', equipment: 'Machine', equipmentRu: 'Тренажёр', equipmentEn: 'Machine' },
          ],
        },
        {
          day: 'Şənbə - Qollar',
          dayRu: 'Суббота - Руки',
          dayEn: 'Saturday - Arms',
          focus: 'Əzələ yığmaq',
          focusRu: 'Набор мышц',
          focusEn: 'Muscle building',
          exercises: [
            { name: 'Close Grip Bench', nameRu: 'Жим узким хватом', nameEn: 'Close Grip Bench', sets: 4, reps: '6-8', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Skullcrushers', nameRu: 'Французский жим', nameEn: 'Skullcrushers', sets: 4, reps: '10-12', rest: '90 san', equipment: 'EZ Bar', equipmentRu: 'EZ-гриф', equipmentEn: 'EZ Bar' },
            { name: 'Barbell Curls', nameRu: 'Сгибания со штангой', nameEn: 'Barbell Curls', sets: 4, reps: '8-10', rest: '90 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Incline Dumbbell Curls', nameRu: 'Сгибания на наклонной скамье', nameEn: 'Incline Dumbbell Curls', sets: 3, reps: '10-12', rest: '60 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
          ],
        },
      ],
    },
    loseWeight: {
      level: 'intermediate',
      duration: '40-50 dəqiqə',
      daysPerWeek: 4,
      workouts: [
        {
          day: 'Bazar ertəsi - Üst Bədən Güc',
          dayRu: 'Понедельник - Сила верха',
          dayEn: 'Monday - Upper Body Strength',
          focus: 'Yağ yandırmaq + Əzələ',
          focusRu: 'Сжигание жира + Мышцы',
          focusEn: 'Fat burn + Muscle',
          exercises: [
            { name: 'Bench Press', nameRu: 'Жим лёжа', nameEn: 'Bench Press', sets: 4, reps: '8-10', rest: '90 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Bent Over Rows', nameRu: 'Тяга в наклоне', nameEn: 'Bent Over Rows', sets: 4, reps: '10-12', rest: '90 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Overhead Press', nameRu: 'Жим над головой', nameEn: 'Overhead Press', sets: 3, reps: '10-12', rest: '90 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Pull-ups', nameRu: 'Подтягивания', nameEn: 'Pull-ups', sets: 3, reps: '8-12', rest: '90 san', equipment: 'Pull-up Bar', equipmentRu: 'Турник', equipmentEn: 'Pull-up Bar' },
          ],
        },
        {
          day: 'Çərşənbə axşamı - HIIT Kardio',
          dayRu: 'Вторник - HIIT Кардио',
          dayEn: 'Tuesday - HIIT Cardio',
          focus: 'Yağ yandırmaq',
          focusRu: 'Сжигание жира',
          focusEn: 'Fat burning',
          exercises: [
            { name: 'Burpees', nameRu: 'Бёрпи', nameEn: 'Burpees', sets: 4, reps: '15', rest: '30 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Kettlebell Swings', nameRu: 'Махи гирей', nameEn: 'Kettlebell Swings', sets: 4, reps: '20', rest: '30 san', equipment: 'Kettlebell', equipmentRu: 'Гиря', equipmentEn: 'Kettlebell' },
            { name: 'Box Jumps', nameRu: 'Прыжки на ящик', nameEn: 'Box Jumps', sets: 4, reps: '12', rest: '30 san', equipment: 'Plyo Box', equipmentRu: 'Плио бокс', equipmentEn: 'Plyo Box' },
            { name: 'Mountain Climbers', nameRu: 'Горные альпинисты', nameEn: 'Mountain Climbers', sets: 4, reps: '30 san', rest: '30 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
          ],
        },
        {
          day: 'Cümə - Aşağı Bədən Güc',
          dayRu: 'Пятница - Сила низа',
          dayEn: 'Friday - Lower Body Strength',
          focus: 'Yağ yandırmaq + Əzələ',
          focusRu: 'Сжигание жира + Мышцы',
          focusEn: 'Fat burn + Muscle',
          exercises: [
            { name: 'Squats', nameRu: 'Приседания', nameEn: 'Squats', sets: 4, reps: '8-10', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Romanian Deadlift', nameRu: 'Румынская тяга', nameEn: 'Romanian Deadlift', sets: 4, reps: '10-12', rest: '90 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Walking Lunges', nameRu: 'Выпады с ходьбой', nameEn: 'Walking Lunges', sets: 3, reps: '12 hər tərəf', rest: '90 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Calf Raises', nameRu: 'Подъёмы на носки', nameEn: 'Calf Raises', sets: 4, reps: '15-20', rest: '45 san', equipment: 'Machine', equipmentRu: 'Тренажёр', equipmentEn: 'Machine' },
          ],
        },
        {
          day: 'Şənbə - Metcon',
          dayRu: 'Суббота - Меткон',
          dayEn: 'Saturday - Metcon',
          focus: 'Yağ yandırmaq',
          focusRu: 'Сжигание жира',
          focusEn: 'Fat burning',
          exercises: [
            { name: 'Thrusters', nameRu: 'Трастеры', nameEn: 'Thrusters', sets: 5, reps: '10', rest: '60 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Rowing Machine', nameRu: 'Гребной тренажёр', nameEn: 'Rowing Machine', sets: 5, reps: '200m', rest: '60 san', equipment: 'Rowing Machine', equipmentRu: 'Гребной тренажёр', equipmentEn: 'Rowing Machine' },
            { name: 'Wall Balls', nameRu: 'Броски мяча в стену', nameEn: 'Wall Balls', sets: 5, reps: '15', rest: '60 san', equipment: 'Medicine Ball', equipmentRu: 'Медбол', equipmentEn: 'Medicine Ball' },
            { name: 'Battle Ropes', nameRu: 'Боевые канаты', nameEn: 'Battle Ropes', sets: 5, reps: '30 san', rest: '30 san', equipment: 'Battle Ropes', equipmentRu: 'Боевые канаты', equipmentEn: 'Battle Ropes' },
          ],
        },
      ],
    },
    maintain: {
      level: 'intermediate',
      duration: '45-55 dəqiqə',
      daysPerWeek: 4,
      workouts: [
        {
          day: 'Bazar ertəsi - Tam Bədən A',
          dayRu: 'Понедельник - Все тело А',
          dayEn: 'Monday - Full Body A',
          focus: 'Formada qalmaq',
          focusRu: 'Поддержание формы',
          focusEn: 'Maintenance',
          exercises: [
            { name: 'Squats', nameRu: 'Приседания', nameEn: 'Squats', sets: 3, reps: '8-10', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Bench Press', nameRu: 'Жим лёжа', nameEn: 'Bench Press', sets: 3, reps: '8-10', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Pull-ups', nameRu: 'Подтягивания', nameEn: 'Pull-ups', sets: 3, reps: '8-12', rest: '90 san', equipment: 'Pull-up Bar', equipmentRu: 'Турник', equipmentEn: 'Pull-up Bar' },
            { name: 'Overhead Press', nameRu: 'Жим над головой', nameEn: 'Overhead Press', sets: 3, reps: '10-12', rest: '90 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
          ],
        },
        {
          day: 'Çərşənbə axşamı - Kardio',
          dayRu: 'Вторник - Кардио',
          dayEn: 'Tuesday - Cardio',
          focus: 'Formada qalmaq',
          focusRu: 'Поддержание формы',
          focusEn: 'Maintenance',
          exercises: [
            { name: 'Running', nameRu: 'Бег', nameEn: 'Running', sets: 1, reps: '20-30 dəq', rest: '-', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Jump Rope', nameRu: 'Прыжки со скакалкой', nameEn: 'Jump Rope', sets: 3, reps: '2 dəq', rest: '1 dəq', equipment: 'Jump Rope', equipmentRu: 'Скакалка', equipmentEn: 'Jump Rope' },
          ],
        },
        {
          day: 'Cümə - Tam Bədən B',
          dayRu: 'Пятница - Все тело Б',
          dayEn: 'Friday - Full Body B',
          focus: 'Formada qalmaq',
          focusRu: 'Поддержание формы',
          focusEn: 'Maintenance',
          exercises: [
            { name: 'Deadlift', nameRu: 'Становая тяга', nameEn: 'Deadlift', sets: 3, reps: '6-8', rest: '2-3 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Incline Dumbbell Press', nameRu: 'Жим гантелей на наклонной', nameEn: 'Incline Dumbbell Press', sets: 3, reps: '10-12', rest: '90 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Barbell Rows', nameRu: 'Тяга штанги в наклоне', nameEn: 'Barbell Rows', sets: 3, reps: '10-12', rest: '90 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Lunges', nameRu: 'Выпады', nameEn: 'Lunges', sets: 3, reps: '10 hər tərəf', rest: '90 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
          ],
        },
        {
          day: 'Şənbə - Funksional',
          dayRu: 'Суббота - Функциональный',
          dayEn: 'Saturday - Functional',
          focus: 'Formada qalmaq',
          focusRu: 'Поддержание формы',
          focusEn: 'Maintenance',
          exercises: [
            { name: 'Kettlebell Swings', nameRu: 'Махи гирей', nameEn: 'Kettlebell Swings', sets: 3, reps: '15', rest: '60 san', equipment: 'Kettlebell', equipmentRu: 'Гиря', equipmentEn: 'Kettlebell' },
            { name: 'Turkish Get-ups', nameRu: 'Турецкие подъёмы', nameEn: 'Turkish Get-ups', sets: 3, reps: '3 hər tərəf', rest: '90 san', equipment: 'Kettlebell', equipmentRu: 'Гиря', equipmentEn: 'Kettlebell' },
            { name: 'Farmers Walk', nameRu: 'Ходьба фермера', nameEn: 'Farmers Walk', sets: 3, reps: '40 metr', rest: '60 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Plank', nameRu: 'Планка', nameEn: 'Plank', sets: 3, reps: '60 san', rest: '60 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
          ],
        },
      ],
    },
  },
  endomorph: {
    gainWeight: {
      level: 'intermediate',
      duration: '45-55 dəqiqə',
      daysPerWeek: 4,
      workouts: [
        {
          day: 'Bazar ertəsi - Göğüs & Triceps',
          dayRu: 'Понедельник - Грудь & Трицепс',
          dayEn: 'Monday - Chest & Triceps',
          focus: 'Kütlə qazanma',
          focusRu: 'Набор массы',
          focusEn: 'Mass gain',
          exercises: [
            { name: 'Bench Press', nameRu: 'Жим лёжа', nameEn: 'Bench Press', sets: 4, reps: '8-10', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Incline Dumbbell Press', nameRu: 'Жим гантелей на наклонной', nameEn: 'Incline Dumbbell Press', sets: 3, reps: '10-12', rest: '90 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Dips', nameRu: 'Отжимания на брусьях', nameEn: 'Dips', sets: 3, reps: '8-12', rest: '90 san', equipment: 'Dip Bars', equipmentRu: 'Брусья', equipmentEn: 'Dip Bars' },
            { name: 'Tricep Pushdowns', nameRu: 'Разгибания трицепса', nameEn: 'Tricep Pushdowns', sets: 3, reps: '12-15', rest: '60 san', equipment: 'Cable', equipmentRu: 'Трос', equipmentEn: 'Cable' },
          ],
        },
        {
          day: 'Çərşənbə axşamı - Arxa & Biceps',
          dayRu: 'Вторник - Спина & Бицепс',
          dayEn: 'Tuesday - Back & Biceps',
          focus: 'Kütlə qazanma',
          focusRu: 'Набор массы',
          focusEn: 'Mass gain',
          exercises: [
            { name: 'Deadlift', nameRu: 'Становая тяга', nameEn: 'Deadlift', sets: 4, reps: '6-8', rest: '3 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Pull-ups', nameRu: 'Подтягивания', nameEn: 'Pull-ups', sets: 3, reps: '8-12', rest: '2 dəq', equipment: 'Pull-up Bar', equipmentRu: 'Турник', equipmentEn: 'Pull-up Bar' },
            { name: 'Barbell Rows', nameRu: 'Тяга штанги в наклоне', nameEn: 'Barbell Rows', sets: 3, reps: '10-12', rest: '90 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Barbell Curls', nameRu: 'Сгибания со штангой', nameEn: 'Barbell Curls', sets: 3, reps: '10-12', rest: '60 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
          ],
        },
        {
          day: 'Cümə - Ayaq & Çiyin',
          dayRu: 'Пятница - Ноги & Плечи',
          dayEn: 'Friday - Legs & Shoulders',
          focus: 'Kütlə qazanma',
          focusRu: 'Набор массы',
          focusEn: 'Mass gain',
          exercises: [
            { name: 'Squats', nameRu: 'Приседания', nameEn: 'Squats', sets: 4, reps: '8-10', rest: '3 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Leg Press', nameRu: 'Жим ногами', nameEn: 'Leg Press', sets: 3, reps: '12-15', rest: '2 dəq', equipment: 'Machine', equipmentRu: 'Тренажёр', equipmentEn: 'Machine' },
            { name: 'Military Press', nameRu: 'Армейский жим', nameEn: 'Military Press', sets: 3, reps: '8-10', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Lateral Raises', nameRu: 'Разведения в стороны', nameEn: 'Lateral Raises', sets: 3, reps: '12-15', rest: '60 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
          ],
        },
        {
          day: 'Şənbə - Tam Bədən',
          dayRu: 'Суббота - Все тело',
          dayEn: 'Saturday - Full Body',
          focus: 'Kütlə qazanma',
          focusRu: 'Набор массы',
          focusEn: 'Mass gain',
          exercises: [
            { name: 'Clean and Press', nameRu: 'Рывок и жим', nameEn: 'Clean and Press', sets: 3, reps: '6-8', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Lunges', nameRu: 'Выпады', nameEn: 'Lunges', sets: 3, reps: '10 hər tərəf', rest: '90 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Face Pulls', nameRu: 'Тяга к лицу', nameEn: 'Face Pulls', sets: 3, reps: '15-20', rest: '60 san', equipment: 'Cable', equipmentRu: 'Трос', equipmentEn: 'Cable' },
            { name: 'Farmer Walks', nameRu: 'Ходьба фермера', nameEn: 'Farmer Walks', sets: 3, reps: '30 metr', rest: '90 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
          ],
        },
      ],
    },
    buildMuscle: {
      level: 'intermediate',
      duration: '50-60 dəqiqə',
      daysPerWeek: 5,
      workouts: [
        {
          day: 'Bazar ertəsi - Göğüs',
          dayRu: 'Понедельник - Грудь',
          dayEn: 'Monday - Chest',
          focus: 'Əzələ yığmaq',
          focusRu: 'Набор мышц',
          focusEn: 'Muscle building',
          exercises: [
            { name: 'Bench Press', nameRu: 'Жим лёжа', nameEn: 'Bench Press', sets: 4, reps: '6-8', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Incline Bench', nameRu: 'Жим на наклонной', nameEn: 'Incline Bench', sets: 4, reps: '8-10', rest: '90 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Dumbbell Flyes', nameRu: 'Разведения гантелей', nameEn: 'Dumbbell Flyes', sets: 3, reps: '12-15', rest: '60 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Cable Crossovers', nameRu: 'Сведения в кроссовере', nameEn: 'Cable Crossovers', sets: 3, reps: '15-20', rest: '60 san', equipment: 'Cable', equipmentRu: 'Трос', equipmentEn: 'Cable' },
          ],
        },
        {
          day: 'Çərşənbə axşamı - Arxa',
          dayRu: 'Вторник - Спина',
          dayEn: 'Tuesday - Back',
          focus: 'Əzələ yığmaq',
          focusRu: 'Набор мышц',
          focusEn: 'Muscle building',
          exercises: [
            { name: 'Deadlift', nameRu: 'Становая тяга', nameEn: 'Deadlift', sets: 4, reps: '5-6', rest: '3 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Weighted Pull-ups', nameRu: 'Подтягивания с весом', nameEn: 'Weighted Pull-ups', sets: 4, reps: '6-8', rest: '2 dəq', equipment: 'Pull-up Bar + Weight', equipmentRu: 'Турник + вес', equipmentEn: 'Pull-up Bar + Weight' },
            { name: 'T-Bar Rows', nameRu: 'Тяга Т-грифа', nameEn: 'T-Bar Rows', sets: 3, reps: '10-12', rest: '90 san', equipment: 'T-Bar', equipmentRu: 'Т-гриф', equipmentEn: 'T-Bar' },
            { name: 'Straight Arm Pulldowns', nameRu: 'Пулдауны с прямыми руками', nameEn: 'Straight Arm Pulldowns', sets: 3, reps: '15-20', rest: '60 san', equipment: 'Cable', equipmentRu: 'Трос', equipmentEn: 'Cable' },
          ],
        },
        {
          day: 'Çərşənbə - Çiyin & Trap',
          dayRu: 'Среда - Плечи & Трапеции',
          dayEn: 'Wednesday - Shoulders & Traps',
          focus: 'Əzələ yığmaq',
          focusRu: 'Набор мышц',
          focusEn: 'Muscle building',
          exercises: [
            { name: 'Overhead Press', nameRu: 'Жим над головой', nameEn: 'Overhead Press', sets: 4, reps: '6-8', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Arnold Press', nameRu: 'Жим Арнольда', nameEn: 'Arnold Press', sets: 3, reps: '10-12', rest: '90 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Upright Rows', nameRu: 'Тяга к подбородку', nameEn: 'Upright Rows', sets: 3, reps: '12-15', rest: '60 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Shrugs', nameRu: 'Шраги', nameEn: 'Shrugs', sets: 4, reps: '12-15', rest: '60 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
          ],
        },
        {
          day: 'Cümə - Ayaq',
          dayRu: 'Пятница - Ноги',
          dayEn: 'Friday - Legs',
          focus: 'Əzələ yığmaq',
          focusRu: 'Набор мышц',
          focusEn: 'Muscle building',
          exercises: [
            { name: 'Squats', nameRu: 'Приседания', nameEn: 'Squats', sets: 5, reps: '6-8', rest: '3 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Romanian Deadlift', nameRu: 'Румынская тяга', nameEn: 'Romanian Deadlift', sets: 4, reps: '8-10', rest: '2 dəq', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Leg Extensions', nameRu: 'Разгибания ног', nameEn: 'Leg Extensions', sets: 3, reps: '15-20', rest: '60 san', equipment: 'Machine', equipmentRu: 'Тренажёр', equipmentEn: 'Machine' },
            { name: 'Hamstring Curls', nameRu: 'Сгибания ног', nameEn: 'Hamstring Curls', sets: 3, reps: '12-15', rest: '60 san', equipment: 'Machine', equipmentRu: 'Тренажёр', equipmentEn: 'Machine' },
          ],
        },
        {
          day: 'Şənbə - Qollar',
          dayRu: 'Суббота - Руки',
          dayEn: 'Saturday - Arms',
          focus: 'Əzələ yığmaq',
          focusRu: 'Набор мышц',
          focusEn: 'Muscle building',
          exercises: [
            { name: 'Close Grip Bench', nameRu: 'Жим узким хватом', nameEn: 'Close Grip Bench', sets: 4, reps: '8-10', rest: '90 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Skullcrushers', nameRu: 'Французский жим', nameEn: 'Skullcrushers', sets: 3, reps: '10-12', rest: '90 san', equipment: 'EZ Bar', equipmentRu: 'EZ-гриф', equipmentEn: 'EZ Bar' },
            { name: 'Barbell Curls', nameRu: 'Сгибания со штангой', nameEn: 'Barbell Curls', sets: 4, reps: '8-10', rest: '90 san', equipment: 'Barbell', equipmentRu: 'Штанга', equipmentEn: 'Barbell' },
            { name: 'Hammer Curls', nameRu: 'Молотковые сгибания', nameEn: 'Hammer Curls', sets: 3, reps: '12-15', rest: '60 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
          ],
        },
      ],
    },
    loseWeight: {
      level: 'beginner',
      duration: '35-45 dəqiqə',
      daysPerWeek: 5,
      workouts: [
        {
          day: 'Bazar ertəsi - Tam Bədən Güc',
          dayRu: 'Понедельник - Сила всего тела',
          dayEn: 'Monday - Full Body Strength',
          focus: 'Yağ yandırmaq',
          focusRu: 'Сжигание жира',
          focusEn: 'Fat burning',
          exercises: [
            { name: 'Goblet Squats', nameRu: 'Приседания с гирей', nameEn: 'Goblet Squats', sets: 3, reps: '12-15', rest: '60 san', equipment: 'Kettlebell', equipmentRu: 'Гиря', equipmentEn: 'Kettlebell' },
            { name: 'Push-ups', nameRu: 'Отжимания', nameEn: 'Push-ups', sets: 3, reps: '10-15', rest: '60 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Dumbbell Rows', nameRu: 'Тяга гантелей', nameEn: 'Dumbbell Rows', sets: 3, reps: '12 hər tərəf', rest: '60 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Plank', nameRu: 'Планка', nameEn: 'Plank', sets: 3, reps: '30-45 san', rest: '45 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
          ],
        },
        {
          day: 'Çərşənbə axşamı - HIIT',
          dayRu: 'Вторник - HIIT',
          dayEn: 'Tuesday - HIIT',
          focus: 'Yağ yandırmaq',
          focusRu: 'Сжигание жира',
          focusEn: 'Fat burning',
          exercises: [
            { name: 'Burpees', nameRu: 'Бёрпи', nameEn: 'Burpees', sets: 4, reps: '10', rest: '30 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Jumping Jacks', nameRu: 'Прыжки с разведением', nameEn: 'Jumping Jacks', sets: 4, reps: '30 san', rest: '30 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'High Knees', nameRu: 'Бег с высокими коленями', nameEn: 'High Knees', sets: 4, reps: '30 san', rest: '30 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Mountain Climbers', nameRu: 'Горные альпинисты', nameEn: 'Mountain Climbers', sets: 4, reps: '30 san', rest: '30 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
          ],
        },
        {
          day: 'Çərşənbə - Aşağı Bədən',
          dayRu: 'Среда - Низ тела',
          dayEn: 'Wednesday - Lower Body',
          focus: 'Yağ yandırmaq',
          focusRu: 'Сжигание жира',
          focusEn: 'Fat burning',
          exercises: [
            { name: 'Bodyweight Squats', nameRu: 'Приседания с весом тела', nameEn: 'Bodyweight Squats', sets: 4, reps: '15-20', rest: '45 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Lunges', nameRu: 'Выпады', nameEn: 'Lunges', sets: 3, reps: '12 hər tərəf', rest: '45 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Glute Bridges', nameRu: 'Мосты для ягодиц', nameEn: 'Glute Bridges', sets: 3, reps: '15-20', rest: '45 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Calf Raises', nameRu: 'Подъёмы на носки', nameEn: 'Calf Raises', sets: 3, reps: '20', rest: '30 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
          ],
        },
        {
          day: 'Cümə - Üst Bədən',
          dayRu: 'Пятница - Верх тела',
          dayEn: 'Friday - Upper Body',
          focus: 'Yağ yandırmaq',
          focusRu: 'Сжигание жира',
          focusEn: 'Fat burning',
          exercises: [
            { name: 'Incline Push-ups', nameRu: 'Отжимания на наклонной', nameEn: 'Incline Push-ups', sets: 3, reps: '12-15', rest: '45 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Resistance Band Rows', nameRu: 'Тяга с резинкой', nameEn: 'Resistance Band Rows', sets: 3, reps: '15', rest: '45 san', equipment: 'Resistance Band', equipmentRu: 'Резинка', equipmentEn: 'Resistance Band' },
            { name: 'Dumbbell Shoulder Press', nameRu: 'Жим гантелей плечами', nameEn: 'Dumbbell Shoulder Press', sets: 3, reps: '12', rest: '45 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Tricep Dips', nameRu: 'Отжимания на трицепс', nameEn: 'Tricep Dips', sets: 3, reps: '10-12', rest: '45 san', equipment: 'Chair', equipmentRu: 'Стул', equipmentEn: 'Chair' },
          ],
        },
        {
          day: 'Şənbə - Kardio & Core',
          dayRu: 'Суббота - Кардио & Пресс',
          dayEn: 'Saturday - Cardio & Core',
          focus: 'Yağ yandırmaq',
          focusRu: 'Сжигание жира',
          focusEn: 'Fat burning',
          exercises: [
            { name: 'Jump Rope', nameRu: 'Прыжки со скакалкой', nameEn: 'Jump Rope', sets: 5, reps: '2 dəq', rest: '30 san', equipment: 'Jump Rope', equipmentRu: 'Скакалка', equipmentEn: 'Jump Rope' },
            { name: 'Russian Twists', nameRu: 'Русские скручивания', nameEn: 'Russian Twists', sets: 3, reps: '20 hər tərəf', rest: '30 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Bicycle Crunches', nameRu: 'Скручивания велосипед', nameEn: 'Bicycle Crunches', sets: 3, reps: '15 hər tərəf', rest: '30 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Leg Raises', nameRu: 'Подъёмы ног', nameEn: 'Leg Raises', sets: 3, reps: '12-15', rest: '30 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
          ],
        },
      ],
    },
    maintain: {
      level: 'beginner',
      duration: '30-40 dəqiqə',
      daysPerWeek: 3,
      workouts: [
        {
          day: 'Bazar ertəsi - Tam Bədən',
          dayRu: 'Понедельник - Все тело',
          dayEn: 'Monday - Full Body',
          focus: 'Formada qalmaq',
          focusRu: 'Поддержание формы',
          focusEn: 'Maintenance',
          exercises: [
            { name: 'Goblet Squats', nameRu: 'Приседания с гирей', nameEn: 'Goblet Squats', sets: 3, reps: '12', rest: '60 san', equipment: 'Kettlebell', equipmentRu: 'Гиря', equipmentEn: 'Kettlebell' },
            { name: 'Push-ups', nameRu: 'Отжимания', nameEn: 'Push-ups', sets: 3, reps: '10-15', rest: '60 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Dumbbell Rows', nameRu: 'Тяга гантелей', nameEn: 'Dumbbell Rows', sets: 3, reps: '10 hər tərəf', rest: '60 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Plank', nameRu: 'Планка', nameEn: 'Plank', sets: 3, reps: '45 san', rest: '45 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
          ],
        },
        {
          day: 'Çərşənbə - Kardio',
          dayRu: 'Среда - Кардио',
          dayEn: 'Wednesday - Cardio',
          focus: 'Formada qalmaq',
          focusRu: 'Поддержание формы',
          focusEn: 'Maintenance',
          exercises: [
            { name: 'Brisk Walking', nameRu: 'Быстрая ходьба', nameEn: 'Brisk Walking', sets: 1, reps: '30 dəq', rest: '-', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Jump Rope', nameRu: 'Прыжки со скакалкой', nameEn: 'Jump Rope', sets: 3, reps: '2 dəq', rest: '1 dəq', equipment: 'Jump Rope', equipmentRu: 'Скакалка', equipmentEn: 'Jump Rope' },
          ],
        },
        {
          day: 'Cümə - Güc & Mobil',
          dayRu: 'Пятница - Сила & Мобильность',
          dayEn: 'Friday - Strength & Mobility',
          focus: 'Formada qalmaq',
          focusRu: 'Поддержание формы',
          focusEn: 'Maintenance',
          exercises: [
            { name: 'Lunges', nameRu: 'Выпады', nameEn: 'Lunges', sets: 3, reps: '10 hər tərəf', rest: '60 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
            { name: 'Dumbbell Press', nameRu: 'Жим гантелей', nameEn: 'Dumbbell Press', sets: 3, reps: '10', rest: '60 san', equipment: 'Dumbbells', equipmentRu: 'Гантели', equipmentEn: 'Dumbbells' },
            { name: 'Resistance Band Pull-aparts', nameRu: 'Разведения с резинкой', nameEn: 'Resistance Band Pull-aparts', sets: 3, reps: '15', rest: '45 san', equipment: 'Resistance Band', equipmentRu: 'Резинка', equipmentEn: 'Resistance Band' },
            { name: 'Cat-Cow Stretch', nameRu: 'Растяжка кошка-корова', nameEn: 'Cat-Cow Stretch', sets: 2, reps: '10', rest: '30 san', equipment: 'Yox', equipmentRu: 'Нет', equipmentEn: 'None' },
          ],
        },
      ],
    },
  },
};

export function useWorkoutProgram() {
  const getProgram = useCallback((bodyType: BodyType, goal: Goal): WorkoutProgram => {
    return workoutPrograms[bodyType][goal];
  }, []);

  return { getProgram };
}
