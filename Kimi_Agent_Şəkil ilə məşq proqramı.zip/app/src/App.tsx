import { useState, useRef, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { Header } from '@/sections/Header';
import { Hero } from '@/sections/Hero';
import { ImageUpload } from '@/sections/ImageUpload';
import { AnalysisResult } from '@/sections/AnalysisResult';
import { WorkoutProgram } from '@/sections/WorkoutProgram';
import { DietProgram } from '@/sections/DietProgram';
import { Footer } from '@/sections/Footer';
import { useImageAnalysis } from '@/hooks/useImageAnalysis';
import { useWorkoutProgram } from '@/hooks/useWorkoutProgram';
import { useDietProgram } from '@/hooks/useDietProgram';
import { Sparkles, RotateCcw, Download, Share2 } from 'lucide-react';
import { toast } from 'sonner';
import './i18n';

function App() {
  const { t } = useTranslation();
  const uploadRef = useRef<HTMLDivElement>(null);
  
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  
  const { isAnalyzing, result, analyzeImage, reset: resetAnalysis } = useImageAnalysis();
  const { getProgram: getWorkoutProgram } = useWorkoutProgram();
  const { getProgram: getDietProgram } = useDietProgram();

  const handleScrollToUpload = useCallback(() => {
    uploadRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  const handleImageSelect = useCallback(async (file: File) => {
    // Create preview URL
    const imageUrl = URL.createObjectURL(file);
    setSelectedImage(imageUrl);
    
    // Analyze image
    await analyzeImage(file);
  }, [analyzeImage]);

  const handleClearImage = useCallback(() => {
    if (selectedImage) {
      URL.revokeObjectURL(selectedImage);
    }
    setSelectedImage(null);
    resetAnalysis();
  }, [selectedImage, resetAnalysis]);

  const handleReset = useCallback(() => {
    handleClearImage();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [handleClearImage]);

  const handleDownload = useCallback(() => {
    toast.info('Yükləmə funksiyası tezliklə əlavə ediləcək!');
  }, []);

  const handleShare = useCallback(() => {
    toast.info('Paylaşma funksiyası tezliklə əlavə ediləcək!');
  }, []);

  const workoutProgram = result ? getWorkoutProgram(result.bodyType, result.goal) : null;
  const dietProgram = result ? getDietProgram(result.bodyType, result.goal) : null;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      
      <main className="flex-1">
        <Hero onScrollToUpload={handleScrollToUpload} />
        
        <div ref={uploadRef} className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Left Column - Image Upload */}
            <div>
              <ImageUpload
                onImageSelect={handleImageSelect}
                isAnalyzing={isAnalyzing}
                selectedImage={selectedImage}
                onClearImage={handleClearImage}
              />
            </div>

            {/* Right Column - Analysis Result */}
            <div>
              {result ? (
                <AnalysisResult result={result} />
              ) : (
                <div className="h-full min-h-[300px] flex flex-col items-center justify-center p-8 bg-muted/50 rounded-xl border border-dashed">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <Sparkles className="w-8 h-8 text-primary" />
                  </div>
                  <p className="text-lg font-medium text-center mb-2">
                    {isAnalyzing ? t('upload.analyzing') : t('app.description')}
                  </p>
                  <p className="text-sm text-muted-foreground text-center">
                    {isAnalyzing 
                      ? 'Zəhmət olmasa gözləyin...' 
                      : 'Şəkil yüklədikdən sonra nəticələr burada görünəcək'}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Programs Section */}
          {result && workoutProgram && dietProgram && (
            <div className="mt-12 space-y-8">
              <div className="flex items-center justify-between max-w-6xl mx-auto">
                <h2 className="text-2xl font-bold">Sizin Fərdi Proqramınız</h2>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleDownload} className="gap-2">
                    <Download className="w-4 h-4" />
                    {t('actions.download')}
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleShare} className="gap-2">
                    <Share2 className="w-4 h-4" />
                    {t('actions.share')}
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleReset} className="gap-2">
                    <RotateCcw className="w-4 h-4" />
                    {t('actions.reset')}
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
                <WorkoutProgram program={workoutProgram} />
                <DietProgram program={dietProgram} />
              </div>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}

export default App;
