import { useTranslation } from 'react-i18next';
import { Sparkles, ArrowDown } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface HeroProps {
  onScrollToUpload: () => void;
}

export function Hero({ onScrollToUpload }: HeroProps) {
  const { t } = useTranslation();

  return (
    <section className="w-full py-16 lg:py-24 bg-gradient-to-b from-primary/5 via-background to-background">
      <div className="container mx-auto px-4 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
          <Sparkles className="w-4 h-4" />
          <span>AI Powered</span>
        </div>

        {/* Title */}
        <h1 className="text-4xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-foreground via-foreground to-muted-foreground bg-clip-text text-transparent">
          {t('app.subtitle')}
        </h1>

        {/* Description */}
        <p className="text-lg lg:text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
          {t('app.description')}
        </p>

        {/* CTA Button */}
        <Button size="lg" onClick={onScrollToUpload} className="gap-2">
          <ArrowDown className="w-4 h-4" />
          {t('actions.generate')}
        </Button>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16 max-w-4xl mx-auto">
          <div className="p-6 bg-card rounded-xl border">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">📸</span>
            </div>
            <h3 className="font-semibold mb-2">Şəkil Yüklə</h3>
            <p className="text-sm text-muted-foreground">Öz şəklini yüklə və AI onu təhlil etsin</p>
          </div>
          
          <div className="p-6 bg-card rounded-xl border">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">🤖</span>
            </div>
            <h3 className="font-semibold mb-2">AI Təhlil</h3>
            <p className="text-sm text-muted-foreground">Süni intellekt bədən tipini müəyyənləşdirsin</p>
          </div>
          
          <div className="p-6 bg-card rounded-xl border">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">💪</span>
            </div>
            <h3 className="font-semibold mb-2">Fərdi Proqram</h3>
            <p className="text-sm text-muted-foreground">Sənə uyğun məşq və qida proqramı al</p>
          </div>
        </div>
      </div>
    </section>
  );
}
