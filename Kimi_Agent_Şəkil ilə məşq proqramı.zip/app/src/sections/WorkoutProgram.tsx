import { useTranslation } from 'react-i18next';
import { Dumbbell, Clock, Calendar, TrendingUp } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import type { WorkoutProgram as WorkoutProgramType } from '@/hooks/useWorkoutProgram';

interface WorkoutProgramProps {
  program: WorkoutProgramType;
}

export function WorkoutProgram({ program }: WorkoutProgramProps) {
  const { t, i18n } = useTranslation();
  const currentLang = i18n.language;

  const getLevelLabel = (level: string) => {
    switch (level) {
      case 'beginner': return t('workout.beginner');
      case 'intermediate': return t('workout.intermediate');
      case 'advanced': return t('workout.advanced');
      default: return level;
    }
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'beginner': return 'bg-green-500';
      case 'intermediate': return 'bg-yellow-500';
      case 'advanced': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getExerciseName = (exercise: any) => {
    switch (currentLang) {
      case 'ru': return exercise.nameRu;
      case 'en': return exercise.nameEn;
      default: return exercise.name;
    }
  };

  const getEquipmentName = (exercise: any) => {
    switch (currentLang) {
      case 'ru': return exercise.equipmentRu;
      case 'en': return exercise.equipmentEn;
      default: return exercise.equipment;
    }
  };

  const getDayName = (workout: any) => {
    switch (currentLang) {
      case 'ru': return workout.dayRu;
      case 'en': return workout.dayEn;
      default: return workout.day;
    }
  };

  const getFocusName = (workout: any) => {
    switch (currentLang) {
      case 'ru': return workout.focusRu;
      case 'en': return workout.focusEn;
      default: return workout.focus;
    }
  };

  return (
    <Card className="w-full">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Dumbbell className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-semibold">{t('workout.title')}</h3>
          </div>
          <Badge className={getLevelColor(program.level)}>
            {getLevelLabel(program.level)}
          </Badge>
        </div>

        {/* Program Info */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
            <Clock className="w-4 h-4 text-muted-foreground" />
            <div>
              <p className="text-xs text-muted-foreground">{t('workout.duration')}</p>
              <p className="text-sm font-medium">{program.duration}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
            <Calendar className="w-4 h-4 text-muted-foreground" />
            <div>
              <p className="text-xs text-muted-foreground">{t('workout.difficulty')}</p>
              <p className="text-sm font-medium">{program.daysPerWeek} {t('workout.daysPerWeek') || 'gün/hafta'}</p>
            </div>
          </div>
        </div>

        {/* Workout Days */}
        <Tabs defaultValue="0" className="w-full">
          <TabsList className="w-full grid grid-cols-2 lg:grid-cols-4 gap-1">
            {program.workouts.map((workout, index) => (
              <TabsTrigger key={index} value={index.toString()} className="text-xs">
                {getDayName(workout).split(' - ')[0]}
              </TabsTrigger>
            ))}
          </TabsList>

          {program.workouts.map((workout, index) => (
            <TabsContent key={index} value={index.toString()}>
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-primary" />
                  <span className="text-sm font-medium">{getFocusName(workout)}</span>
                </div>

                <div className="space-y-3">
                  {workout.exercises.map((exercise, exIndex) => (
                    <div
                      key={exIndex}
                      className="p-4 bg-muted rounded-lg hover:bg-muted/80 transition-colors"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-medium">{getExerciseName(exercise)}</h4>
                        <Badge variant="outline" className="text-xs">
                          {getEquipmentName(exercise)}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="text-muted-foreground">{t('workout.sets')}:</span>
                          <span className="ml-1 font-medium">{exercise.sets}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">{t('workout.reps')}:</span>
                          <span className="ml-1 font-medium">{exercise.reps}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">{t('workout.rest')}:</span>
                          <span className="ml-1 font-medium">{exercise.rest}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
}
