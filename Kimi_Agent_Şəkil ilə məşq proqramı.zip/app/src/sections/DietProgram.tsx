import { useTranslation } from 'react-i18next';
import { Utensils, Droplets, Flame, Beef, Wheat as WheatIcon, Droplet } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import type { DietProgram as DietProgramType } from '@/hooks/useDietProgram';

interface DietProgramProps {
  program: DietProgramType;
}

export function DietProgram({ program }: DietProgramProps) {
  const { t, i18n } = useTranslation();
  const currentLang = i18n.language;

  const getMealName = (meal: any) => {
    switch (currentLang) {
      case 'ru': return meal.nameRu;
      case 'en': return meal.nameEn;
      default: return meal.name;
    }
  };

  const getFoods = (meal: any) => {
    switch (currentLang) {
      case 'ru': return meal.foodsRu;
      case 'en': return meal.foodsEn;
      default: return meal.foods;
    }
  };

  const totalSnackCalories = program.meals.snacks.reduce((sum, snack) => sum + snack.calories, 0);
  const totalSnackProtein = program.meals.snacks.reduce((sum, snack) => sum + snack.protein, 0);
  const totalSnackCarbs = program.meals.snacks.reduce((sum, snack) => sum + snack.carbs, 0);
  const totalSnackFats = program.meals.snacks.reduce((sum, snack) => sum + snack.fats, 0);

  return (
    <Card className="w-full">
      <CardContent className="p-6">
        <div className="flex items-center gap-2 mb-6">
          <Utensils className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-semibold">{t('diet.title')}</h3>
        </div>

        {/* Daily Targets */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
          <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
            <div className="flex items-center gap-2 mb-1">
              <Flame className="w-4 h-4 text-orange-500" />
              <span className="text-xs text-muted-foreground">{t('diet.calories')}</span>
            </div>
            <p className="text-lg font-bold text-orange-600">{program.dailyCalories}</p>
          </div>
          
          <div className="p-3 bg-red-50 rounded-lg border border-red-200">
            <div className="flex items-center gap-2 mb-1">
              <Beef className="w-4 h-4 text-red-500" />
              <span className="text-xs text-muted-foreground">{t('diet.protein')}</span>
            </div>
            <p className="text-lg font-bold text-red-600">{program.dailyProtein}g</p>
          </div>
          
          <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
            <div className="flex items-center gap-2 mb-1">
              <WheatIcon className="w-4 h-4 text-yellow-600" />
              <span className="text-xs text-muted-foreground">{t('diet.carbs')}</span>
            </div>
            <p className="text-lg font-bold text-yellow-700">{program.dailyCarbs}g</p>
          </div>
          
          <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-center gap-2 mb-1">
              <Droplet className="w-4 h-4 text-blue-500" />
              <span className="text-xs text-muted-foreground">{t('diet.fats')}</span>
            </div>
            <p className="text-lg font-bold text-blue-600">{program.dailyFats}g</p>
          </div>
        </div>

        {/* Water */}
        <div className="flex items-center gap-3 p-4 bg-cyan-50 rounded-lg border border-cyan-200 mb-6">
          <div className="w-10 h-10 rounded-full bg-cyan-100 flex items-center justify-center">
            <Droplets className="w-5 h-5 text-cyan-600" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">{t('diet.water')}</p>
            <p className="font-medium text-cyan-700">{program.waterLiters}L / gün</p>
          </div>
        </div>

        {/* Meals */}
        <div className="space-y-4">
          {/* Breakfast */}
          <div className="p-4 bg-muted rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium text-primary">{getMealName(program.meals.breakfast)}</h4>
              <Badge variant="outline">{program.meals.breakfast.calories} kcal</Badge>
            </div>
            <ul className="space-y-1 text-sm">
              {getFoods(program.meals.breakfast).map((food: string, index: number) => (
                <li key={index} className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary"></span>
                  {food}
                </li>
              ))}
            </ul>
            <div className="flex gap-4 mt-3 text-xs text-muted-foreground">
              <span>P: {program.meals.breakfast.protein}g</span>
              <span>C: {program.meals.breakfast.carbs}g</span>
              <span>F: {program.meals.breakfast.fats}g</span>
            </div>
          </div>

          {/* Lunch */}
          <div className="p-4 bg-muted rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium text-primary">{getMealName(program.meals.lunch)}</h4>
              <Badge variant="outline">{program.meals.lunch.calories} kcal</Badge>
            </div>
            <ul className="space-y-1 text-sm">
              {getFoods(program.meals.lunch).map((food: string, index: number) => (
                <li key={index} className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary"></span>
                  {food}
                </li>
              ))}
            </ul>
            <div className="flex gap-4 mt-3 text-xs text-muted-foreground">
              <span>P: {program.meals.lunch.protein}g</span>
              <span>C: {program.meals.lunch.carbs}g</span>
              <span>F: {program.meals.lunch.fats}g</span>
            </div>
          </div>

          {/* Dinner */}
          <div className="p-4 bg-muted rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium text-primary">{getMealName(program.meals.dinner)}</h4>
              <Badge variant="outline">{program.meals.dinner.calories} kcal</Badge>
            </div>
            <ul className="space-y-1 text-sm">
              {getFoods(program.meals.dinner).map((food: string, index: number) => (
                <li key={index} className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary"></span>
                  {food}
                </li>
              ))}
            </ul>
            <div className="flex gap-4 mt-3 text-xs text-muted-foreground">
              <span>P: {program.meals.dinner.protein}g</span>
              <span>C: {program.meals.dinner.carbs}g</span>
              <span>F: {program.meals.dinner.fats}g</span>
            </div>
          </div>

          {/* Snacks */}
          <div className="p-4 bg-muted rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium text-primary">{t('diet.snacks')}</h4>
              <Badge variant="outline">{totalSnackCalories} kcal</Badge>
            </div>
            <div className="space-y-3">
              {program.meals.snacks.map((snack, index) => (
                <div key={index} className="text-sm">
                  <p className="font-medium text-muted-foreground mb-1">{getMealName(snack)}</p>
                  <ul className="space-y-1 pl-4">
                    {getFoods(snack).map((food: string, foodIndex: number) => (
                      <li key={foodIndex} className="flex items-center gap-2 text-muted-foreground">
                        <span className="w-1 h-1 rounded-full bg-muted-foreground"></span>
                        {food}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
            <div className="flex gap-4 mt-3 text-xs text-muted-foreground">
              <span>P: {totalSnackProtein}g</span>
              <span>C: {totalSnackCarbs}g</span>
              <span>F: {totalSnackFats}g</span>
            </div>
          </div>
        </div>

        {/* Macros Progress */}
        <div className="mt-6 pt-6 border-t">
          <p className="text-sm font-medium mb-4">{t('diet.dailyTarget')}</p>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-muted-foreground">{t('diet.protein')}</span>
                <span>{program.dailyProtein}g</span>
              </div>
              <Progress value={100} className="h-2 bg-red-100" />
            </div>
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-muted-foreground">{t('diet.carbs')}</span>
                <span>{program.dailyCarbs}g</span>
              </div>
              <Progress value={100} className="h-2 bg-yellow-100" />
            </div>
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-muted-foreground">{t('diet.fats')}</span>
                <span>{program.dailyFats}g</span>
              </div>
              <Progress value={100} className="h-2 bg-blue-100" />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
