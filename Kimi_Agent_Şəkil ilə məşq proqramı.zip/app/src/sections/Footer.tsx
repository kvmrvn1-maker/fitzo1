import { useTranslation } from 'react-i18next';
import { Dumbbell, Heart } from 'lucide-react';

export function Footer() {
  const { t } = useTranslation();

  return (
    <footer className="w-full border-t bg-muted/50">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Dumbbell className="w-4 h-4 text-primary" />
            </div>
            <span className="font-semibold">{t('app.title')}</span>
          </div>

          {/* Copyright */}
          <p className="text-sm text-muted-foreground flex items-center gap-1">
            Made with <Heart className="w-4 h-4 text-red-500 fill-red-500" /> by FitAI Team
          </p>

          {/* Links */}
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span>© 2025 FitAI</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
