import { useTranslation } from 'react-i18next';
import { Activity, Target, TrendingUp, Droplets } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import type { AnalysisResult as AnalysisResultType } from '@/hooks/useImageAnalysis';

interface AnalysisResultProps {
  result: AnalysisResultType;
}

export function AnalysisResult({ result }: AnalysisResultProps) {
  const { t } = useTranslation();

  const getGoalLabel = (goal: string) => {
    switch (goal) {
      case 'loseWeight': return t('analysis.loseWeight');
      case 'gainWeight': return t('analysis.gainWeight');
      case 'maintain': return t('analysis.maintain');
      case 'buildMuscle': return t('analysis.buildMuscle');
      default: return goal;
    }
  };

  const getGoalColor = (goal: string) => {
    switch (goal) {
      case 'loseWeight': return 'bg-red-500';
      case 'gainWeight': return 'bg-green-500';
      case 'maintain': return 'bg-blue-500';
      case 'buildMuscle': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  const getBodyTypeLabel = (bodyType: string) => {
    return t(`bodyTypes.${bodyType}`);
  };

  const getBMICategory = (bmi: number) => {
    if (bmi < 18.5) return { label: 'İncə', color: 'text-yellow-500' };
    if (bmi < 25) return { label: 'Normal', color: 'text-green-500' };
    if (bmi < 30) return { label: 'Artıq çəki', color: 'text-orange-500' };
    return { label: 'Obez', color: 'text-red-500' };
  };

  const bmiCategory = getBMICategory(result.estimatedBMI);

  return (
    <Card className="w-full">
      <CardContent className="p-6">
        <div className="flex items-center gap-2 mb-6">
          <Activity className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-semibold">{t('analysis.title')}</h3>
        </div>

        <div className="space-y-6">
          {/* Body Type */}
          <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{t('analysis.bodyType')}</p>
                <p className="font-medium">{getBodyTypeLabel(result.bodyType)}</p>
              </div>
            </div>
          </div>

          {/* BMI */}
          <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Droplets className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{t('analysis.bmi')}</p>
                <p className="font-medium">{result.estimatedBMI} <span className={`text-sm ${bmiCategory.color}`}>({bmiCategory.label})</span></p>
              </div>
            </div>
          </div>

          {/* Goal */}
          <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Target className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{t('analysis.recommendation')}</p>
                <p className="font-medium">{getGoalLabel(result.goal)}</p>
              </div>
            </div>
            <Badge className={getGoalColor(result.goal)}>
              {getGoalLabel(result.goal)}
            </Badge>
          </div>

          {/* Confidence */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">{t('analysis.confidence')}</span>
              <span className="font-medium">{Math.round(result.confidence)}%</span>
            </div>
            <Progress value={result.confidence} className="h-2" />
          </div>

          {/* Description */}
          <div className="p-4 bg-primary/5 rounded-lg border border-primary/20">
            <p className="text-sm text-muted-foreground">{result.description}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
